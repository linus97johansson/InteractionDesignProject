$(document).ready(function ($) {
    $.getScript('script/menu.js', function () {

        console.log("success");
    });
    $.getScript('script/login.js', function () {

        console.log("success");
    });



});